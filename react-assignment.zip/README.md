# Assignment Code for React SSR, Redux

